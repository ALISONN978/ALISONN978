﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PListaExercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta1;
            double aresta2;
            double resultado;

            Console.WriteLine("Calcula a area de um quadrado a partir deste software");
            Console.WriteLine("Entre com o valor da primeira aresta");
            aresta1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Entre com o valor da segunda aresta");
            aresta2 = int.Parse(Console.ReadLine());
            resultado = aresta1 * aresta2;
            Console.WriteLine("Aqui esta o valor da area do quadrado");
            Console.WriteLine(resultado);
            Console.ReadLine();


        }
    }
}
