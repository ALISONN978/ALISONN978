﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PListaExercicio3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double lado;
            double diagonal;
            double resultado;

            Console.WriteLine("Obtenha o valor da area de um quadrado a partir de sua diagonal");
            Console.WriteLine("Digite o valor da diagonal");


        }
    }
}
