﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PListaExercicio6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double numero1;
            double numero2;
            double resultado;

            Console.WriteLine("Obtenha o valor da media geometrica de dois numeros");
            Console.WriteLine("Digite o primeiro numero");
            numero1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo numero");
            numero2 = int.Parse(Console.ReadLine());
            resultado = numero1 * numero2 / 2;

            Console.WriteLine("Aqui esta o valor");
            Console.WriteLine(resultado);
            Console.ReadLine();

        }
    }
}
