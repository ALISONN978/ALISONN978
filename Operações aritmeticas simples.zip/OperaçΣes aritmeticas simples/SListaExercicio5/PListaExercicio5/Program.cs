﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PListaExercicio5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double valor3;  
            double valor4;  
            double valor5;

            Console.WriteLine("Obtenha a media aritmetica de quatro valores");
            Console.WriteLine("Digite o primeiro valor");
            valor1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o segundo valor");
            valor2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o terceiro valor");
            valor3 = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o quarto valor");
            valor4 = int.Parse(Console.ReadLine());

            valor5 = valor1 * valor2 * valor3 * valor4 / 4;
            Console.WriteLine("Aqui está: ");
            Console.WriteLine(valor5);
            Console.ReadLine();


        }
    }
}
